package crud_prueba_alumnos.crudalumnos;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudalumnosApplicationTests {

	
	void contextLoads() {
	}

}
